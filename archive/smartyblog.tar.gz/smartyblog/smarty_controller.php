<?php
require_once( 'Smarty.class.php' );	


class CSmartyController extends CController
{
	var $smarty			= null;
	var $viewfile_ext	= ".tpl";


    function CSmartyController()
    {
        $this->smarty = new Smarty;
        $this->smarty->compile_check = true;
    }

    function set( $key, $value )
    {
        $this->smarty->assign( $key, $value );
    }
}