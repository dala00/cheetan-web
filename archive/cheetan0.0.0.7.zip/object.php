<?php
/*-----------------------------------------------------------------------------
cheetan is licensed under the MIT license.
copyright (c) 2006 cheetan all right reserved.
http://www.cheetan.net/
-----------------------------------------------------------------------------*/
class CObject
{
	
}
?>