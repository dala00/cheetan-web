<?php
/*-----------------------------------------------------------------------------
cheetan is licensed under the MIT license.
copyright (c) 2006 cheetan all right reserved.
http://www.cheetan.net/
-----------------------------------------------------------------------------*/
class CDatabaseConfig extends CObject
{
	var	$host;
	var	$user;
	var $pswd;
	var	$db;
}


class CDatabase extends CObject
{
	var	$config			= array();
	var $connect		= array();
	
	
	function add( $name, $host, $user, $pswd, $db )
	{
		$config	= new CDatabaseConfig();
		$config->host			= $host;
		$config->user			= $user;
		$config->pswd			= $pswd;
		$config->db				= $db;
		$this->config[$name]	= $config;
	}
	
	
	function connect()
	{
		foreach( $this->config as $name => $config )
		{
			$connect = mysql_connect( $config->host, $config->user, $config->pswd );
			if( !$connect )
			{
				print "Failed connect to $name.<br>";
			}
			else
			{
			    mysql_select_db( $config->db, $connect );
			}
			$this->connect[$name] = $connect;
		}
	}
	
	
	function query( $query, $name = "" )
	{
		$ret	= mysql_query( $query, $this->connect[$name] );
		if( !$ret )
		{
			print "[DBERR] $query<BR>";
		}
		
		return $ret;
	}
	
	
	function find( $query, $name = "" )
	{
		$ret	= array();
		if( $res = $this->query( $query, $name ) )
		{
			while( $row = mysql_fetch_assoc( $res ) )
			{
				array_push( $ret, $row );
			}
		}
		
		return $ret;
	}
	
	
	function count( $query, $name = "" )
	{
		if( $res = $this->query( $query, $name ) )
		{
			return mysql_num_rows( $res );
		}
		
		return 0;
	}
}
?>