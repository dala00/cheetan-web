<?php
define('LIB_DIR', dirname(__FILE__) . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR);
require_once LIB_DIR . 'config' . DIRECTORY_SEPARATOR . 'config.php';
