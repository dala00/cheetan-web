<?php
$databases = array(
	'' => array(
		'connect' => '',
		'host' => 'localhost',
		'login' => '',
		'password' => '',
		'database' => '',
		'encoding' => '',
	),
);